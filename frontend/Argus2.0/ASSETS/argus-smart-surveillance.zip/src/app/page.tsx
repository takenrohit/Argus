import { useMemo, useState } from 'react';
import MapComponent from '../components/MapComponent';
import ThreatIndicator from '../components/ThreatIndicator';
import { Incident } from '../types';
import { Activity, Filter, ChevronDown, MoreHorizontal, AlertCircle, CheckCircle2, Map as MapIcon, Layers, Plus } from 'lucide-react';
import { cn } from '../lib/utils';

interface DashboardPageProps {
  incidents: Incident[];
  onSelectIncident: (inc: Incident) => void;
}

export default function DashboardPage({ incidents, onSelectIncident }: DashboardPageProps) {
  const [showHeatmap, setShowHeatmap] = useState(true);
  
  const topThreats = useMemo(() => {
    return incidents.filter(i => i.confidence > 75).sort((a, b) => b.confidence - a.confidence).slice(0, 3);
  }, [incidents]);

  return (
    <div className="flex flex-1 h-full overflow-hidden">
      {/* Left Sidebar Metrics */}
      <div className="w-80 border-r border-brand-border flex flex-col p-6 overflow-y-auto custom-scrollbar gap-8 bg-brand-dark/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 px-3 py-1 bg-white/5 border border-brand-border rounded-lg">
             <Filter className="w-3 h-3 text-white/40" />
             <span className="text-xs font-bold">Filters</span>
             <span className="text-[10px] bg-white/10 px-1 rounded font-mono text-white/60">0</span>
          </div>
          <div className="flex items-center gap-2 text-xs font-bold text-white/60 cursor-pointer hover:text-white transition-colors">
             Weekly
             <ChevronDown className="w-4 h-4" />
          </div>
        </div>

        {/* Active Devices Chart Placeholder */}
        <section>
          <div className="flex justify-between items-end mb-4">
            <h3 className="text-xs font-bold uppercase tracking-widest text-white/40 font-mono">Active devices</h3>
            <MoreHorizontal className="w-4 h-4 text-white/20" />
          </div>
          <div className="glass-card p-4 relative overflow-hidden h-32 flex flex-col justify-between">
             <div className="flex items-start justify-between">
                <div>
                   <p className="text-xl font-bold text-white tracking-tight">2.5k</p>
                   <p className="text-[10px] text-brand-green font-mono">↑ 12% vs LY</p>
                </div>
                <span className="text-xs font-mono text-white/40 bg-white/5 px-1.5 py-0.5 rounded leading-none">63%</span>
             </div>
             {/* Simulated Mini Line Chart */}
             <div className="absolute inset-x-0 bottom-0 h-10 flex items-end px-2 gap-1 translate-y-1">
                {[4, 7, 5, 8, 10, 8, 9, 7, 8, 6, 9, 7, 10].map((h, i) => (
                  <div key={i} className="flex-1 bg-white/5 rounded-t-sm transition-all hover:bg-brand-blue/30 cursor-pointer" style={{ height: `${h * 10}%` }} />
                ))}
                <div className="absolute inset-0 bg-gradient-to-t from-brand-blue/10 via-transparent to-transparent pointer-events-none" />
             </div>
          </div>
        </section>

        {/* Alerts Gauge Placeholder */}
        <section>
          <div className="flex justify-between items-end mb-4">
            <h3 className="text-xs font-bold uppercase tracking-widest text-white/40 font-mono">Alerts</h3>
            <MoreHorizontal className="w-4 h-4 text-white/20" />
          </div>
          <div className="glass-card p-6 flex flex-col items-center relative overflow-hidden">
             <div className="absolute top-0 right-0 p-2">
                 <MoreHorizontal className="w-3 h-3 text-white/10" />
             </div>
             <div className="relative w-40 h-20 overflow-hidden">
                <div className="absolute top-0 w-40 h-40 border-[16px] border-white/5 rounded-full" />
                <div className="absolute top-0 w-40 h-40 border-[16px] border-transparent border-t-brand-red rounded-full rotate-[120deg] shadow-[0_0_20px_rgba(255,77,77,0.2)]" />
                <div className="absolute inset-0 flex flex-col items-center justify-center pt-8">
                   <p className="text-2xl font-bold tracking-tight">64.32%</p>
                   <p className="text-[10px] text-white/40 uppercase font-mono tracking-widest">DEVICES: 1.3K / 2.5K</p>
                </div>
             </div>
             <div className="grid grid-cols-3 gap-4 w-full mt-6 pt-4 border-t border-white/5">
                <div className="flex flex-col items-center gap-1.5">
                   <div className="w-2 h-2 rounded-full bg-brand-red shadow-[0_0_8px_rgba(255,77,77,0.4)]" />
                   <span className="text-[9px] text-white/30 uppercase font-bold tracking-widest">Critical</span>
                </div>
                <div className="flex flex-col items-center gap-1.5">
                   <div className="w-2 h-2 rounded-full bg-brand-amber shadow-[0_0_8px_rgba(255,153,51,0.4)]" />
                   <span className="text-[9px] text-white/30 uppercase font-bold tracking-widest">Warnings</span>
                </div>
                <div className="flex flex-col items-center gap-1.5">
                   <div className="w-2 h-2 rounded-full bg-white/20" />
                   <span className="text-[9px] text-white/30 uppercase font-bold tracking-widest">No Alerts</span>
                </div>
             </div>
          </div>
        </section>

        {/* Global Distribution */}
        <section>
          <div className="flex justify-between items-end mb-4">
            <h3 className="text-xs font-bold uppercase tracking-widest text-white/40 font-mono">Distribution of devices</h3>
            <MoreHorizontal className="w-4 h-4 text-white/20" />
          </div>
          <div className="grid grid-cols-3 gap-3">
             {[
               { label: 'Hospitals', p: 7, color: 'brand-blue' },
               { label: 'Home', p: 64, color: 'brand-green' },
               { label: 'In Transit', p: 28, color: 'brand-amber' }
             ].map((item, i) => (
                <div key={i} className="glass-card p-3 flex flex-col items-center gap-2">
                   <div className="w-10 h-10 rounded-full border-2 border-white/5 flex items-center justify-center relative">
                      <span className="text-[10px] font-bold">{item.p}%</span>
                      <svg className="absolute inset-0 w-full h-full -rotate-90">
                         <circle cx="20" cy="20" r="18" fill="transparent" stroke="currentColor" strokeWidth="2" className={cn("text-opacity-40", `text-${item.color === 'brand-blue' ? 'brand-blue' : item.color === 'brand-green' ? 'brand-green' : 'brand-amber'}`)} strokeDasharray="113" strokeDashoffset={113 - (113 * item.p / 100)} />
                      </svg>
                   </div>
                   <span className="text-[8px] text-white/40 uppercase font-bold text-center leading-tight truncate w-full">{item.label}</span>
                </div>
             ))}
          </div>
        </section>

        {/* Critical Issues */}
        <section className="flex-1 min-h-0">
          <div className="flex justify-between items-end mb-4">
            <h3 className="text-xs font-bold uppercase tracking-widest text-white/40 font-mono">Critical Issues <span className="ml-2 text-white/10">8</span></h3>
            <MoreHorizontal className="w-4 h-4 text-white/20" />
          </div>
          <div className="space-y-3 pb-4">
             {incidents.filter(i => i.confidence > 80).map(inc => (
               <button 
                 key={inc.id}
                 onClick={() => onSelectIncident(inc)}
                 className="w-full glass-card p-3 flex items-start gap-4 hover:bg-white/5 transition-all text-left group"
               >
                 <div className="w-10 h-10 rounded-xl bg-brand-red/10 group-hover:bg-brand-red/20 transition-colors flex items-center justify-center border border-brand-red/20 shadow-inner">
                    <Activity className="w-5 h-5 text-brand-red" />
                 </div>
                 <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold truncate group-hover:text-brand-red transition-colors">{inc.type}</p>
                    <p className="text-[10px] text-white/40 font-mono truncate">{inc.location.address}</p>
                 </div>
                 <div className="w-1.5 h-1.5 rounded-full bg-brand-red self-center animate-pulse shadow-[0_0_8px_rgba(255,77,77,0.6)]" />
               </button>
             ))}
          </div>
        </section>
      </div>

      {/* Main Content Area: Tactical Map */}
      <div className="flex-1 flex flex-col bg-brand-dark overflow-hidden relative">
        <div className="absolute top-6 left-6 right-6 flex items-center justify-between z-[1000] pointer-events-none">
           <div className="flex items-center gap-3 pointer-events-auto">
              <button className="px-5 py-2.5 rounded-xl bg-brand-dark/80 backdrop-blur-xl border border-white/10 text-xs font-bold text-white shadow-2xl transition-all hover:bg-brand-dark">Network</button>
              <button 
                onClick={() => setShowHeatmap(!showHeatmap)}
                className={cn(
                  "px-5 py-2.5 rounded-xl backdrop-blur-xl border border-white/10 text-xs font-bold transition-all hover:border-white/20 pointer-events-auto",
                  showHeatmap ? "bg-white/10 text-white" : "bg-brand-dark/40 text-white/40"
                )}
              >
                Heatmap
              </button>
           </div>
           
           <div className="flex items-center gap-4 pointer-events-auto">
              <div className="bg-brand-dark/80 backdrop-blur-xl px-4 py-2.5 rounded-xl border border-white/10 flex items-center gap-2 shadow-2xl">
                 <div className="w-2 h-2 rounded-full bg-brand-green animate-pulse" />
                 <span className="text-[10px] font-mono font-bold tracking-widest text-white/40 uppercase">System Status: Optimal</span>
              </div>
           </div>
        </div>

        <div className="flex-1 p-0 overflow-hidden relative z-0">
          <MapComponent 
            incidents={incidents} 
            onSelectIncident={onSelectIncident}
            showHeatmap={showHeatmap}
          />

          {/* Map Overlay Widgets */}
          <div className="absolute top-24 right-8 flex flex-col gap-3 z-[1000] pointer-events-auto">
             {topThreats.map(threat => (
               <ThreatIndicator key={threat.id} type={threat.type} confidence={threat.confidence} />
             ))}
          </div>

          {/* Floating UI Elements from Reference Image */}
          <div className="absolute bottom-8 left-8 right-8 flex gap-4 pointer-events-none z-[1000]">
             <div className="glass-card bg-brand-dark/90 backdrop-blur-2xl px-6 py-5 flex-1 flex items-center gap-6 border-l-4 border-l-brand-red shadow-[0_32px_64px_-16px_rgba(0,0,0,0.5)] pointer-events-auto group hover:border-l-brand-red transition-all cursor-pointer">
                <div className="w-12 h-12 rounded-2xl bg-brand-red/10 flex items-center justify-center border border-brand-red/20 shadow-inner group-hover:scale-110 transition-transform">
                   <Activity className="w-6 h-6 text-brand-red" />
                </div>
                <div className="flex-1 min-w-0">
                   <p className="text-[10px] font-mono text-white/30 truncate uppercase tracking-[0.2em] mb-1">Target tracking active</p>
                   <p className="font-bold text-base tracking-tight capitalize group-hover:text-white transition-colors">{incidents[0].type} signature identified</p>
                </div>
                <MoreHorizontal className="w-5 h-5 text-white/20" />
             </div>
             
             <div className="glass-card bg-brand-dark/90 backdrop-blur-2xl px-6 py-5 flex-1 flex items-center gap-6 border-l-4 border-l-brand-blue shadow-[0_32px_64px_-16px_rgba(0,0,0,0.5)] pointer-events-auto group hover:border-l-brand-blue transition-all cursor-pointer">
                <div className="w-12 h-12 rounded-2xl bg-brand-blue/10 flex items-center justify-center border border-brand-blue/20 shadow-inner group-hover:scale-110 transition-transform">
                   <CheckCircle2 className="w-6 h-6 text-brand-blue" />
                </div>
                <div className="flex-1 min-w-0">
                   <p className="text-[10px] font-mono text-white/30 truncate uppercase tracking-[0.2em] mb-1">Argus Vision Cluster-04</p>
                   <p className="font-bold text-base tracking-tight group-hover:text-white transition-colors">Spatial Analysis complete</p>
                </div>
                <MoreHorizontal className="w-5 h-5 text-white/20" />
             </div>
          </div>
          
          {/* Bottom Right Floating Map Controls */}
          <div className="absolute bottom-24 right-8 flex flex-col gap-3 z-[1000] pointer-events-auto">
             <button className="p-3 bg-brand-dark/80 backdrop-blur-xl border border-white/10 rounded-2xl hover:bg-brand-dark transition-all shadow-xl group">
                <Layers className="w-5 h-5 text-white/40 group-hover:text-white" />
             </button>
             <button className="p-3 bg-white border border-brand-border rounded-full hover:bg-white/90 transition-all shadow-xl group text-black">
                <Plus className="w-5 h-5" />
             </button>
          </div>
        </div>
      </div>
    </div>
  );
}
