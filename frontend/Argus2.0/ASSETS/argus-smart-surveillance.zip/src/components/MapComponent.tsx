import React from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { Incident } from '../types';

// Fix for default marker icons in Leaflet with React
// @ts-ignore
delete L.Icon.Default.prototype._getIconUrl;

const createCustomIcon = (color: string) => {
  return L.divIcon({
    className: 'custom-div-icon',
    html: `<div style="background-color: ${color}; width: 12px; height: 12px; border-radius: 50%; border: 3px solid rgba(255,255,255,0.2); box-shadow: 0 0 15px ${color};"></div>`,
    iconSize: [12, 12],
    iconAnchor: [6, 6],
  });
};

const redIcon = createCustomIcon('#ff4d4d');
const amberIcon = createCustomIcon('#ff9933');

interface MapComponentProps {
  incidents: Incident[];
  onSelectIncident: (incident: Incident) => void;
  showHeatmap: boolean;
}

export default function MapComponent({ incidents, onSelectIncident, showHeatmap }: MapComponentProps) {
  const center: [number, number] = [40.7128, -74.0060]; // NYC default

  return (
    <div className="h-full w-full relative z-0">
      <MapContainer 
        center={center} 
        zoom={13} 
        scrollWheelZoom={true} 
        className="w-full h-full"
        zoomControl={false}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        />
        
        {incidents.map((incident) => (
          <React.Fragment key={incident.id}>
            <Marker 
              position={[incident.location.lat, incident.location.lng]}
              icon={incident.confidence > 80 ? redIcon : amberIcon}
              eventHandlers={{
                click: () => onSelectIncident(incident),
              }}
            >
              <Popup className="custom-leaflet-popup">
                <div className="text-white p-3 bg-brand-surface rounded-xl border border-brand-border shadow-2xl min-w-[180px]">
                  <div className="font-bold flex items-center justify-between mb-2">
                    <span className="text-xs uppercase tracking-widest">{incident.type}</span>
                    <div className={cn(
                      "w-1.5 h-1.5 rounded-full animate-pulse",
                      incident.confidence > 80 ? "bg-brand-red" : "bg-brand-amber"
                    )} />
                  </div>
                  <div className="text-[10px] text-white/40 font-mono mb-2">{incident.location.address}</div>
                  <div className="flex items-center justify-between pt-2 border-t border-white/5">
                    <span className="text-[10px] font-bold text-white/60">CONFIDENCE</span>
                    <span className="text-[10px] font-mono text-brand-blue">{incident.confidence}%</span>
                  </div>
                </div>
              </Popup>
            </Marker>

            {showHeatmap && (
              <Circle
                center={[incident.location.lat, incident.location.lng]}
                pathOptions={{ 
                  fillColor: incident.confidence > 80 ? '#ff4d4d' : '#ff9933',
                  color: 'transparent',
                  fillOpacity: 0.15
                }}
                radius={300 + (incident.confidence - 50) * 10}
              />
            )}
          </React.Fragment>
        ))}
      </MapContainer>
    </div>
  );
}

import { cn } from '../lib/utils';
