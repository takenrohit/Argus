import { Search, Filter, Download, MoreHorizontal, Eye, ShieldAlert, BadgeCheck, ChevronDown, Layers, Activity } from 'lucide-react';
import { Incident } from '../types';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface IncidentHistoryProps {
  incidents: Incident[];
  onSelect: (incident: Incident) => void;
}

export default function IncidentHistory({ incidents, onSelect }: IncidentHistoryProps) {
  return (
    <div className="flex-1 p-8 overflow-y-auto bg-brand-dark custom-scrollbar flex flex-col gap-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight mb-1">Incident History & Management</h2>
          <p className="text-white/30 text-xs font-mono uppercase tracking-widest">Argus Strategic Node Ledger</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 p-1 bg-white/5 border border-brand-border rounded-2xl">
             <button className="px-5 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest text-white/30">Overview</button>
             <button className="px-5 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest text-white/30 bg-white/5 border border-brand-border">Active Incidents</button>
             <button className="px-5 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest text-white bg-brand-blue shadow-[0_0_10px_rgba(0,204,255,0.2)]">History</button>
             <button className="px-5 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest text-white/30">Reports</button>
          </div>
          <button className="p-3 bg-white/5 border border-brand-border rounded-2xl hover:bg-white/10 transition-all text-white/40 hover:text-white">
             <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex gap-8 flex-1 min-h-0">
         {/* Left stats column */}
         <div className="w-80 flex flex-col gap-8">
            <section>
               <div className="flex justify-between items-end mb-4 px-2">
                 <h3 className="text-[10px] font-bold uppercase tracking-widest text-white/40 font-mono">Incident Overview</h3>
                 <MoreHorizontal className="w-4 h-4 text-white/20" />
               </div>
               <div className="glass-card p-6 flex flex-col gap-6">
                  <div className="flex items-center justify-between text-[10px] font-mono text-white/30 uppercase tracking-widest">
                     <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-brand-red" /> Critical by Severity</span>
                     <span>Severity</span>
                  </div>
                  {/* Simulated Bar Chart */}
                  <div className="flex items-end gap-3 h-32 px-2">
                     {[20, 35, 65, 45, 15, 10, 8].map((h, i) => (
                       <div key={i} className="flex-1 bg-white/5 rounded-t-lg relative group transition-all cursor-pointer">
                          <div 
                            className={cn("absolute bottom-0 inset-x-0 rounded-t-lg transition-all", i === 2 ? "bg-brand-amber/60" : "bg-brand-red/40")} 
                            style={{ height: `${h}%` }} 
                          />
                          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-full mb-2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap bg-brand-dark border border-brand-border p-1 rounded text-[8px] font-mono shadow-2xl z-10">
                            {h} Units
                          </div>
                       </div>
                     ))}
                  </div>
               </div>
            </section>

            <section>
               <div className="flex justify-between items-end mb-4 px-2">
                 <h3 className="text-[10px] font-bold uppercase tracking-widest text-white/40 font-mono">Status Breakdown</h3>
                 <MoreHorizontal className="w-4 h-4 text-white/20" />
               </div>
               <div className="glass-card p-6 flex flex-col items-center">
                  <div className="relative w-32 h-32">
                     <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                        <circle cx="50" cy="50" r="40" fill="transparent" stroke="rgba(255,255,255,0.05)" strokeWidth="12" />
                        <circle cx="50" cy="50" r="40" fill="transparent" stroke="#33cc33" strokeWidth="12" strokeDasharray="251.2" strokeDashoffset="138.1" strokeLinecap="round" />
                     </svg>
                     <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <p className="text-2xl font-bold tracking-tighter">45%</p>
                        <p className="text-[8px] text-white/30 uppercase tracking-widest">Active</p>
                     </div>
                  </div>
                  <div className="w-full space-y-2 mt-6">
                     {[
                        { label: 'Critical', color: 'brand-red', count: '12%' },
                        { label: 'Status Reviews', color: 'brand-amber', count: '28%' },
                        { label: 'Minor', color: 'white/10', count: '60%' }
                     ].map((s, i) => (
                        <div key={i} className="flex items-center justify-between">
                           <div className="flex items-center gap-2">
                              <div className={cn("w-1.5 h-1.5 rounded-full bg-opacity-80", `bg-${s.color}`)} />
                              <span className="text-[10px] text-white/50">{s.label}</span>
                           </div>
                           <span className="text-[10px] font-mono text-white/30">{s.count}</span>
                        </div>
                     ))}
                  </div>
               </div>
            </section>
         </div>

         {/* Main history log column */}
         <div className="flex-1 flex flex-col gap-4">
            <div className="flex justify-between items-end mb-2 px-2">
               <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/30">Incident History Log</h3>
               <div className="flex items-center gap-3">
                  <Download className="w-4 h-4 text-white/20 hover:text-white cursor-pointer transition-colors" />
               </div>
            </div>
            
            <div className="glass-card flex-1 overflow-hidden flex flex-col shadow-2xl">
               <div className="p-4 border-b border-brand-border flex items-center gap-6 bg-white/[0.01]">
                  <div className="flex items-center gap-2 text-[10px] font-bold text-white/40 uppercase tracking-widest">
                     Timeframe: <span className="text-white">All Days</span> <ChevronDown className="w-3 h-3" />
                  </div>
                  <div className="flex items-center gap-2 text-[10px] font-bold text-white/40 uppercase tracking-widest border-l border-brand-border pl-6">
                     Status: <span className="text-white">All</span> <ChevronDown className="w-3 h-3" />
                  </div>
                  <div className="flex-1 relative border-l border-brand-border pl-6">
                     <Search className="absolute left-9 top-1/2 -translate-y-1/2 w-4 h-4 text-white/10" />
                     <input 
                        type="text" 
                        placeholder="Search 30 Days Log..." 
                        className="w-full bg-transparent border-none text-xs text-white/60 focus:ring-0 placeholder:text-white/10 ml-0 py-1" 
                     />
                  </div>
               </div>

               <div className="flex-1 overflow-y-auto custom-scrollbar">
                  <table className="w-full text-left border-collapse">
                     <thead className="sticky top-0 z-10 bg-brand-surface/95 backdrop-blur-md">
                        <tr className="border-b border-brand-border">
                           <th className="p-6 text-[10px] font-bold uppercase tracking-[0.2em] text-white/20">Title</th>
                           <th className="p-6 text-[10px] font-bold uppercase tracking-[0.2em] text-white/20">Severity</th>
                           <th className="p-6 text-[10px] font-bold uppercase tracking-[0.2em] text-white/20">Status</th>
                           <th className="p-6 text-[10px] font-bold uppercase tracking-[0.2em] text-white/20">Assigned To</th>
                           <th className="p-6 text-[10px] font-bold uppercase tracking-[0.2em] text-white/20 text-right">Last Update</th>
                        </tr>
                     </thead>
                     <tbody className="divide-y divide-white/[0.03]">
                        {incidents.map((incident) => (
                           <motion.tr 
                              key={incident.id}
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              onClick={() => onSelect(incident)}
                              className="group hover:bg-white/[0.02] cursor-pointer transition-colors"
                           >
                              <td className="p-6">
                                 <div>
                                    <p className="text-sm font-bold text-white/80 group-hover:text-brand-blue transition-colors">{incident.type}</p>
                                    <p className="text-[10px] text-white/30 font-mono mt-1">{incident.location.address}</p>
                                 </div>
                              </td>
                              <td className="p-6">
                                 <span className={cn(
                                    "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest",
                                    incident.confidence > 80 ? "bg-brand-red/10 text-brand-red border border-brand-red/20 shadow-[0_0_10px_rgba(255,77,77,0.1)]" : "bg-brand-amber/10 text-brand-amber border border-brand-amber/20"
                                 )}>
                                    {incident.confidence > 80 ? 'Critical' : 'Major'}
                                 </span>
                              </td>
                              <td className="p-6">
                                 <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">
                                    {incident.status === 'resolved' ? 'Resolved' : 'Open'}
                                 </span>
                              </td>
                              <td className="p-6">
                                 <div className="flex items-center gap-2">
                                    <div className="w-5 h-5 rounded-full bg-white/5 border border-white/10 flex items-center justify-center">
                                       <User className="w-3 h-3 text-white/30" />
                                    </div>
                                    <span className="text-xs text-white/60">A. Chen</span>
                                 </div>
                              </td>
                              <td className="p-6 text-right font-mono text-[10px] text-white/20">
                                 2 min ago
                              </td>
                           </motion.tr>
                        ))}
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
}

import { Settings } from 'lucide-react';
