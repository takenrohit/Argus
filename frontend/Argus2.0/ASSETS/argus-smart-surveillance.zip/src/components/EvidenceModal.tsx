import { X, Shield, MapPin, Activity, CheckCircle2, Siren, Trash2, Send, Clock, User, Download, FileText, ChevronRight, AlertTriangle } from 'lucide-react';
import { Incident } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface EvidenceModalProps {
  incident: Incident | null;
  onClose: () => void;
  onAction: (id: string, action: 'dispatch' | 'dismiss' | 'escalate') => void;
}

export default function EvidenceModal({ incident, onClose, onAction }: EvidenceModalProps) {
  if (!incident) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/90 backdrop-blur-md"
        />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-6xl bg-brand-dark border border-brand-border rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col h-[90vh]"
        >
          {/* Header */}
          <div className="h-16 border-b border-brand-border flex items-center px-8 bg-white/5 backdrop-blur-xl relative">
            <div className="flex gap-4 border-r border-brand-border pr-8 mr-8 h-full items-center">
               <button className="text-xs font-bold text-white px-4 py-1.5 bg-white/10 rounded-xl">Overview</button>
               <button className="text-xs font-bold text-white/40 hover:text-white/60 transition-colors uppercase tracking-widest">Logs</button>
               <button className="text-xs font-bold text-white/40 hover:text-white/60 transition-colors uppercase tracking-widest font-mono">Devices</button>
            </div>
            
            <div className="flex-1 flex justify-center">
               <h2 className="text-xs font-bold uppercase tracking-[0.4em] text-white/70">Incident & Evidence Report</h2>
            </div>

            <button 
              onClick={onClose}
              className="absolute right-8 p-2 rounded-full hover:bg-white/10 transition-colors border border-brand-border group"
            >
              <X className="w-5 h-5 text-white/40 group-hover:text-white" />
            </button>
          </div>

          <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
            {/* Left Column: Details */}
            <div className="w-full md:w-80 border-r border-brand-border bg-black/20 p-8 flex flex-col gap-6 overflow-y-auto custom-scrollbar">
              <section>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-[10px] font-bold uppercase tracking-widest text-white/30">Incident Details</h3>
                  <MoreHorizontal className="w-4 h-4 text-white/20" />
                </div>
                <div className="glass-card p-5 space-y-5">
                  <div className="flex items-center justify-between">
                     <p className="text-[10px] text-white/40 uppercase font-bold">Incident ID</p>
                     <div className="w-4 h-4 rounded bg-brand-green shadow-[0_0_10px_rgba(51,204,51,0.5)]" />
                  </div>
                  <div>
                     <p className="text-[10px] text-white/40 uppercase font-bold mb-2">Reported By</p>
                     <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                           <User className="w-4 h-4 text-white/40" />
                        </div>
                        <p className="text-xs font-bold">Dr. Anya Sharma</p>
                     </div>
                  </div>
                  <div className="flex items-start gap-3">
                     <Clock className="w-4 h-4 text-white/30 mt-0.5" />
                     <div>
                        <p className="text-xs font-bold">{incident.timestamp}</p>
                        <p className="text-[10px] text-white/40 font-mono">2024-03-15 | 14:37 UTC</p>
                     </div>
                  </div>
                  <div className="pt-5 border-t border-brand-border">
                     <p className="text-[10px] text-white/40 uppercase font-bold mb-3">Priority</p>
                     <div className="grid grid-cols-2 gap-2">
                        <button className="py-2 rounded-xl bg-white/5 border border-brand-border text-[10px] font-bold uppercase tracking-widest text-white/40">High</button>
                        <button className="py-2 rounded-xl bg-brand-amber text-black text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-brand-amber/20">In Progress</button>
                     </div>
                  </div>
                </div>
              </section>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 p-8 grid grid-cols-1 lg:grid-cols-2 gap-8 overflow-y-auto custom-scrollbar">
               {/* Devices Involved */}
               <section>
                  <div className="flex justify-between items-end mb-4 px-2">
                    <h3 className="text-[10px] font-bold uppercase tracking-[0.25em] text-white/30">Device(s) Involved</h3>
                    <MoreHorizontal className="w-4 h-4 text-white/20" />
                  </div>
                  <div className="glass-card p-6 space-y-4">
                     {[
                       { name: 'Argus Node-04 (Main)', type: incident.type, status: 'Resolved', color: 'brand-green' },
                       { name: 'StaticCam H-40', type: 'Secondary Feed', status: 'Critical', color: 'brand-red' },
                       { name: 'Drone X-9', type: 'Aerial Recon', status: 'Active', color: 'brand-amber' }
                     ].map((dev, i) => (
                       <div key={i} className="flex items-center gap-4 bg-white/5 p-3 rounded-2xl border border-white/5 group hover:bg-white/10 transition-all">
                          <div className={cn("w-10 h-10 rounded-2xl flex items-center justify-center bg-opacity-10", `bg-${dev.color}`)}>
                             <Activity className={cn("w-5 h-5", `text-${dev.color}`)} />
                          </div>
                          <div className="flex-1 min-w-0">
                             <p className="text-xs font-bold truncate">{dev.name}</p>
                             <p className="text-[10px] text-white/40 font-mono">{dev.type}</p>
                          </div>
                          <span className={cn("px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-widest border border-opacity-30", `bg-${dev.color}/10 text-${dev.color} border-${dev.color}`)}>
                             {dev.status}
                          </span>
                       </div>
                     ))}
                  </div>
               </section>

               {/* Evidence & Logs */}
               <section>
                  <div className="flex justify-between items-end mb-4 px-2">
                    <h3 className="text-[10px] font-bold uppercase tracking-[0.25em] text-white/30">Evidence & Logs</h3>
                    <MoreHorizontal className="w-4 h-4 text-white/20" />
                  </div>
                  <div className="glass-card p-6 space-y-4 flex flex-col h-full">
                     {[
                        { name: 'Thermal_Scan_20240315.raw', size: '142.4 MB' },
                        { name: 'Detection_Log_04.csv', size: '1.2 MB' }
                     ].map((file, i) => (
                       <div key={i} className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-brand-border group hover:border-white/20 transition-all cursor-pointer">
                          <FileText className="w-6 h-6 text-white/30 group-hover:text-brand-blue" />
                          <div className="flex-1">
                             <p className="text-xs font-bold">{file.name}</p>
                             <p className="text-[10px] text-white/40 font-mono">Status: Verified | {file.size}</p>
                          </div>
                          <Download className="w-4 h-4 text-white/20 group-hover:text-white" />
                       </div>
                     ))}
                     <button className="mt-4 w-full py-4 rounded-2xl border-2 border-dashed border-brand-border flex items-center justify-center gap-2 text-xs font-bold text-white/20 hover:text-white/40 hover:border-brand-border/40 transition-all">
                        <Plus className="w-4 h-4" />
                        Upload New Evidence
                     </button>
                  </div>
               </section>

               {/* Description & Status */}
               <section className="lg:col-span-1">
                  <div className="flex justify-between items-end mb-4 px-2">
                    <h3 className="text-[10px] font-bold uppercase tracking-[0.25em] text-white/30">Description</h3>
                    <MoreHorizontal className="w-4 h-4 text-white/20" />
                  </div>
                  <div className="glass-card p-6 flex flex-col gap-6">
                     <p className="text-sm text-white/60 leading-relaxed italic">
                        "Artificial intelligence cluster Node-04 flagged multi-frame pose orientation anomaly matching 'Physical Struggle' signature with {incident.confidence}% confidence. Subject tracking active."
                     </p>
                     
                     <div className="pt-6 border-t border-brand-border">
                        <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-4">Status Update</p>
                        <div className="grid grid-cols-3 gap-3">
                           <button className="py-3 rounded-2xl bg-brand-red/10 border border-brand-red/30 text-brand-red text-[10px] font-bold uppercase tracking-widest shadow-inner glow-red">High</button>
                           <button className="py-3 rounded-2xl bg-brand-amber text-black text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-brand-amber/20">In Progress</button>
                           <button className="py-3 rounded-2xl bg-white/5 border border-brand-border text-white/40 text-[10px] font-bold uppercase tracking-widest">Closed</button>
                        </div>
                     </div>
                  </div>
               </section>

               {/* System Logs */}
               <section className="lg:col-span-1">
                  <div className="flex justify-between items-end mb-4 px-2">
                    <h3 className="text-[10px] font-bold uppercase tracking-[0.25em] text-white/30">System Logs (Filtered)</h3>
                    <MoreHorizontal className="w-4 h-4 text-white/20" />
                  </div>
                  <div className="glass-card p-6 bg-black/40 flex flex-col h-[280px]">
                     <div className="flex-1 overflow-y-auto custom-scrollbar font-mono text-[10px] space-y-2 text-white/30 uppercase">
                        <p><span className="text-brand-green">[SYSTEM]</span> Kernel initialization complete</p>
                        <p><span className="text-brand-blue">[OP-04]</span> Tracking active: Subject_Target_Alpha</p>
                        <p><span className="text-brand-red font-bold underline">[CRITICAL]</span> Pose Orientation Mismatch identified</p>
                        <p><span className="text-white/10">--- Frame Analysis Buffer (142kb) ---</span></p>
                        <p><span className="text-brand-amber">[WARN]</span> Lighting conditions &lt; 20 lux, IR active</p>
                        <p><span className="text-brand-blue">[OP-04]</span> Re-linking secondary nodes...</p>
                        <p><span className="text-brand-green">[SYSTEM]</span> Dispatch queue populated</p>
                     </div>
                  </div>
               </section>

               {/* Timeline View */}
               <section className="lg:col-span-2 pb-8">
                  <div className="flex items-center gap-2 mb-4 px-2">
                    <h3 className="text-[10px] font-bold uppercase tracking-[0.25em] text-white/30">Timeline View</h3>
                  </div>
                  <div className="glass-card p-8 flex items-center gap-4 relative">
                     <div className="absolute inset-x-12 top-1/2 -translate-y-1/2 h-0.5 bg-white/5" />
                     {[14.35, 14.36, 14.37, 14.38].map((time, i) => (
                       <div key={i} className="flex-1 flex flex-col items-center gap-4 relative z-10">
                          <button className={cn(
                            "w-4 h-4 rounded-full transition-all border-4 bg-brand-dark hover:scale-125",
                            i === 2 ? "border-brand-red scale-125 glow-red shadow-[0_0_10px_rgba(255,77,77,0.5)]" : i < 2 ? "border-brand-green" : "border-white/10"
                          )} />
                          <span className={cn("text-[10px] font-mono", i === 2 ? "text-white font-bold" : "text-white/20")}>{time.toFixed(2)}</span>
                       </div>
                     ))}
                  </div>
               </section>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="h-20 border-t border-brand-border bg-brand-dark/40 backdrop-blur-xl px-8 flex items-center justify-between">
             <div className="flex gap-4">
                <button 
                  onClick={onClose}
                  className="px-8 py-3 rounded-2xl bg-white/5 border border-brand-border text-xs font-bold text-white/60 hover:text-white hover:bg-white/10 transition-all uppercase tracking-widest"
                >
                  Cancel
                </button>
                <button className="px-8 py-3 rounded-2xl bg-white/5 border border-brand-border text-xs font-bold text-white/60 hover:text-white hover:bg-white/10 transition-all uppercase tracking-widest">
                  Save Draft
                </button>
             </div>
             
             <button 
               onClick={() => onAction(incident.id, 'dispatch')}
               className="px-12 py-3 rounded-2xl bg-brand-green text-black text-xs font-bold uppercase tracking-[0.2em] shadow-2xl shadow-brand-green/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-3"
             >
               Finalize Report
               <ChevronRight className="w-4 h-4" />
             </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
