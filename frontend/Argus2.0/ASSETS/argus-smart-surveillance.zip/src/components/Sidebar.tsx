import { Shield, LayoutDashboard, Database, Bell, Activity, FileText, Settings, HelpCircle, LogOut, Search, User } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'devices', label: 'Devices', icon: Database },
    { id: 'alerts', label: 'Alerts', icon: Bell },
    { id: 'incidents', label: 'Incidents', icon: FileText },
    { id: 'analytics', label: 'Analytics', icon: Activity },
    { id: 'reports', label: 'Reports', icon: Shield },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'help', label: 'Help', icon: HelpCircle },
  ];

  return (
    <aside className="w-56 border-r border-brand-border flex flex-col h-full bg-brand-dark/50 backdrop-blur-xl">
      <div className="p-8 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full border-2 border-brand-blue flex items-center justify-center p-1.5 shadow-[0_0_15px_rgba(0,204,255,0.3)]">
          <div className="w-full h-full bg-brand-blue rounded-full flex items-center justify-center">
            <Shield className="w-4 h-4 text-brand-dark fill-current" />
          </div>
        </div>
        <h1 className="font-bold tracking-tight text-lg text-white">Logeo</h1>
      </div>

      <nav className="flex-1 px-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id || (item.id === 'incidents' && activeTab === 'incidents') || (item.id === 'analytics' && activeTab === 'analytics');
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-300 relative group",
                isActive 
                  ? "bg-brand-blue/10 text-brand-blue shadow-[inset_0_0_10px_rgba(0,204,255,0.05)]" 
                  : "text-white/40 hover:text-white/70 hover:bg-white/5"
              )}
            >
              <Icon className={cn("w-5 h-5 transition-colors", isActive ? "text-brand-blue" : "text-white/30 group-hover:text-white/60")} />
              <span className="text-sm font-medium tracking-tight">{item.label}</span>
              {isActive && (
                <motion.div 
                  layoutId="activeTab"
                  className="absolute left-0 w-1 h-6 bg-brand-blue rounded-r-full"
                />
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-6 mt-auto border-t border-brand-border/50">
        <div className="flex items-center gap-3 px-2 py-3 rounded-2xl hover:bg-white/5 transition-colors cursor-pointer group">
          <div className="w-10 h-10 rounded-full bg-white/10 border border-white/10 flex items-center justify-center overflow-hidden">
             <User className="w-5 h-5 text-white/40" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-white truncate">Officer Jenkins</p>
            <p className="text-[10px] text-white/40 truncate font-mono">9422-QX</p>
          </div>
          <LogOut className="w-4 h-4 text-white/20 group-hover:text-brand-red transition-colors" />
        </div>
      </div>
    </aside>
  );
}
