import { useState, useMemo } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import AlertPanel from './components/AlertPanel';
import EvidenceModal from './components/EvidenceModal';
import DashboardPage from './app/page';
import IncidentsPage from './app/incidents/page';
import MapPage from './app/map/page';
import { Incident } from './types';

const MOCK_INCIDENTS: Incident[] = [
  {
    id: 'inc-01',
    type: 'Physical Struggle',
    confidence: 94,
    timestamp: '05:42:10 AM',
    location: { lat: 40.730610, lng: -73.935242, address: '42nd St, New York, NY' },
    status: 'reviewing',
    evidenceUrl: 'https://images.unsplash.com/photo-1502472545332-e2416896a188?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'inc-02',
    type: 'Being Followed',
    confidence: 68,
    timestamp: '05:38:22 AM',
    location: { lat: 40.712776, lng: -74.005974, address: 'Broadway, New York, NY' },
    status: 'active',
  },
  {
    id: 'inc-03',
    type: 'Unattended Package',
    confidence: 82,
    timestamp: '05:30:15 AM',
    location: { lat: 40.758896, lng: -73.985130, address: 'Times Square, New York, NY' },
    status: 'dispatching',
  },
  {
    id: 'inc-04',
    type: 'Unauthorized Access',
    confidence: 55,
    timestamp: '05:15:00 AM',
    location: { lat: 40.706086, lng: -73.996864, address: 'DUMBO, Brooklyn, NY' },
    status: 'active',
  }
];

function MainContent() {
  const [incidents, setIncidents] = useState<Incident[]>(MOCK_INCIDENTS);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  const activeTab = location.pathname === '/' ? 'dashboard' : location.pathname.split('/')[1];

  const criticalAlert = useMemo(() => {
    return incidents.find(i => i.confidence > 90 && i.status === 'reviewing') || null;
  }, [incidents]);

  const handleAction = (id: string, action: 'dispatch' | 'dismiss' | 'escalate') => {
    setIncidents(prev => prev.map(inc => {
      if (inc.id === id) {
        if (action === 'dispatch') return { ...inc, status: 'dispatching' };
        if (action === 'dismiss') return { ...inc, status: 'dismissed' };
        if (action === 'escalate') return { ...inc, confidence: Math.min(100, inc.confidence + 5) };
      }
      return inc;
    }));
    setSelectedIncident(null);
  };

  const handlePageChange = (tab: string) => {
    if (tab === 'dashboard') navigate('/');
    else navigate(`/${tab}`);
  };

  return (
    <div className="flex h-screen bg-brand-dark overflow-hidden font-sans">
      <Sidebar activeTab={activeTab} setActiveTab={handlePageChange} />
      
      <main className="flex-1 flex flex-col min-w-0 relative">
        <AlertPanel criticalIncident={criticalAlert} />
        
        <div className="flex-1 relative overflow-hidden">
          <Routes>
            <Route path="/" element={<DashboardPage incidents={incidents} onSelectIncident={setSelectedIncident} />} />
            <Route path="/incidents" element={<IncidentsPage incidents={incidents} onSelectIncident={setSelectedIncident} />} />
            <Route path="/analytics" element={<MapPage incidents={incidents} onSelectIncident={setSelectedIncident} />} />
            <Route path="/settings" element={
              <div className="h-full flex items-center justify-center text-white/20 uppercase tracking-[0.5em] font-mono text-xl">
                 System Encryption Locked
              </div>
            } />
          </Routes>
        </div>
      </main>

      <EvidenceModal 
        incident={selectedIncident} 
        onClose={() => setSelectedIncident(null)}
        onAction={handleAction}
      />
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <MainContent />
    </Router>
  );
}


