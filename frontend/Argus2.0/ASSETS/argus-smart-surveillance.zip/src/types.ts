export type IncidentSeverity = 'CRITICAL' | 'REVIEW' | 'MONITOR' | 'SYSTEM';

export interface Incident {
  id: string;
  type: string;
  confidence: number;
  timestamp: string;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  status: 'active' | 'reviewing' | 'dispatching' | 'resolved' | 'dismissed';
  evidenceUrl?: string;
  keypoints?: number[][]; // [x, y] coordinates for poses
}

export interface CameraStream {
  id: string;
  name: string;
  status: 'active' | 'tracking' | 'offline';
  location: string;
  feedUrl: string;
}
